<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />




<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-69617546-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- Autor -->

  <meta name="Author" content="Breno Gonçalves">

  <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta http-equiv="content-type" content="text/html;charset=utf-8" />

  <link href="ico.png" rel="shortcut icon" type="image/x-icon">

  <meta http-equiv="X-UA-Compatible" content="IE=5; IE=8" >

<!-- Autor -->



<!-- Portugues do Brasil -->

  <meta name="Language" content="pt-br">



<!-- Reponsive -->

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta charset="UTF-8">

<!-- Reponsive -->

<style type="text/css">
	@media handheld, only screen and (max-width: 600px){


        input[type="number"] {
    width: 80%;
    display: block;
    margin: auto;
    -webkit-appearance: textfield;
    -webkit-rtl-ordering: logical;
    user-select: text;
    cursor: auto;
    padding: 5px 0px;
    border-width: 0px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    font-family: arial;
    font-size: 20px;
   
    text-align: center;
    margin-top: 10px;
}


		a#voltar, p{
			color: #000;
			font-size: 20px;
			font-family: arial;
			text-decoration: none;
			
			padding-top: 10px;
		}

.webe{
	width: 95%;
	margin: 0px auto;
}

		body{

            color: #4f4a4a;
            font-family: arial;
            font-size: 20px;
			margin: 0px;
			padding: 0px;
                width: 100%;
    
    float: left;



		}
        label{
            color: #4f4a4a !important;
            margin-right: 20px;
        }

input[type="radio" i] {
    margin: 3px 3px 0px 5px;
}
input[type="radio" i] {
    -webkit-appearance: radio;
    box-sizing: border-box;
}


		input[type=text] {
    width: 80%;
    display: block;
    margin: auto;
    -webkit-appearance: textfield;
    -webkit-rtl-ordering: logical;
    user-select: text;
    cursor: auto;
    padding: 5px 0px;
    border-width: 0px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    font-family: arial;
    font-size: 20px;
    border-left: solid 5px #cdcdcd;
    text-align: center;
    margin-top: 10px;


}

input[type="submit"] {
    padding: 15px 32px;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    font-family: arial;
    border-radius: 10px;
    border: solid .5px #cdcdcd;
    background: #fff;
    color: #585858;
    margin-top: 10px;
    text-align: center;
    float: left;
    width: 100%;

}

:focus {
    outline: -webkit-focus-ring-color auto 0px;
}

textarea#mensagem {
    background: rgba(0, 0, 0, 0) !important;
    width: 80%;
    display: block;
    margin: 0px;
    -webkit-appearance: textfield;
    background-color: white;
    -webkit-rtl-ordering: logical;
    user-select: text;
    cursor: auto;
    padding: 5px 0px;
    border-width: 0px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    font-size: 20px;
    font-family: arial;
    border-left: solid 5px #cdcdcd;
   margin: auto;
    text-align: center;
    margin-top: 10px;

}

INPUT::-webkit-input-placeholder, 
INPUT:-moz-placeholder {
    color:#000;
}
input[placeholder], [placeholder], *[placeholder]
{
    color:#585858 !important;
}
::-webkit-input-placeholder {
    color:#585858;
}

::-moz-placeholder {
    color:#585858;
}

::-ms-placeholder {
    color:#585858;
}

::placeholder {
    color:#585858;
}




	}

@media handheld, only screen and (max-width: 99999px) and (min-width: 601px){

		a#voltar, p{
			color: #4a4a4a;
			font-size: 20px;
			font-family: arial;
			text-decoration: none;
			
			padding-top: 10px;
		}


		body{
            color: #000;
            font-family: arial;
            font-size: 20px;
			margin: 0px;
			padding: 0px;
                width: 100%;





		}


 
input[type="radio" i] {

    width: 13px;
    height: 13px;
    border-radius: 7px;
}

         label{
          
                color: #4f4a4a !important;
            }

input[type=text] {
    background: rgba(0, 0, 0, 0) !important;
    width: 100%;
    display: block;
    margin: 0px;
    -webkit-appearance: textfield;
    background-color: white;
    -webkit-rtl-ordering: logical;
    user-select: text;
    cursor: auto;
    padding: 5px 0px;
    border-width: 0px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    font-size: 20px;
    font-family: arial;
    border-left: 5px solid #cdcdcd;
    margin-top: 10px;
    text-align: center;

}

input[type="submit"] {
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 20px;
    font-family: arial;
    border-radius: 500px;
    border: solid .5px #4a4a4a;
    color: #585858;
    position: fixed;
    right: 100px;
    bottom: 100px;
    height: 89px;
    width: 89px;
    background: #fff;
}

input[type="submit"]:active{
    background-color: rgba(0, 0, 0, 0); /* Green */
    color: #000;
    transition: .1s;
    border: 1px solid #000;
}

textarea#mensagem {
    background: rgba(0, 0, 0, 0) !important;
    width: 100%;
    display: block;
    margin: 0px;
    -webkit-appearance: textfield;
    background-color: white;
    -webkit-rtl-ordering: logical;
    user-select: text;
    cursor: auto;
    padding: 5px 0px;
    border-width: 0px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    font-size: 20px;
    font-family: arial;
    border-left: 5px solid #cdcdcd;
    text-align: center;
    margin-top: 10px;

}



input:focus, textarea:focus, keygen:focus, select:focus {
    outline-offset: -2px;
    box-shadow: 0px 0px 5px #7d7d7d;
    transition: .5s;
}
user agent stylesheet
:focus {
    outline: -webkit-focus-ring-color auto 5px;
}

.webe{
	width: 590px;
	margin: 0px auto;
}
INPUT::-webkit-input-placeholder, 
INPUT:-moz-placeholder {
    color:#000;
}
input[placeholder], [placeholder], *[placeholder]
{
    color:#4a4a4a !important;
}
::-webkit-input-placeholder {
    color:#4a4a4a;
}

::-moz-placeholder {
    color:#4a4a4a;
}

::-ms-placeholder {
    color:#4a4a4a;
}

::placeholder {
    color:#4a4a4a;
}

}

:focus {
    outline: -webkit-focus-ring-color auto 0px;
}


input[type="number"] {
    width: 80%;
    display: block;
    margin: auto;
    -webkit-appearance: textfield;
    -webkit-rtl-ordering: logical;
    user-select: text;
    cursor: auto;
    padding: 5px 0px;
    border-width: 0px;
    border-style: inset;
    border-color: initial;
    border-image: initial;
    font-family: arial;
    font-size: 20px;
  
    text-align: center;
    margin-top: 10px;
}


	}

form{
    width: 90%;
    margin: auto}
</style>
</head>

<body>

    <?php include_once("analyticstracking.php") ?>
<script language="javascript" type="text/javascript">
var rec="O preenchimento do campo é obrigatório"
function aviso(){
if("" == document.meuform.nome.value)
{document.write("preenchimento obrigatorio");return false;}
else{return true;}}
</script>

<?php
if (isset($_POST['BTEnvia'])){
 
	//REMETENTE --> ESTE EMAIL TEM QUE SER VALIDO DO DOMINIO
 	//====================================================
	$email_remetente = "contato@brenodeveloper.esy.es"; // deve ser um email do dominio
	//====================================================
 
 
	//Configurações do email, ajustar conforme necessidade
	//====================================================
	$email_destinatario = "contato@brenodeveloper.esy.es"; // qualquer email pode receber os dados
	$email_reply = "$email";
	$email_assunto = "Contato formmail";
	//====================================================
 
 
	//Variaveis de POST, Alterar somente se necessário
	//====================================================
	$nome = $_POST['nome'];
	$email = $_POST['email'];
    $cep = $_POST['cep'];
    $endereco = $_POST['endereco'];
    $numero = $_POST['numero'];
    $complemento = $_POST['complemento'];
    $bairro = $_POST['bairro'];
    $site = $_POST['site'];
    $pagamento = $_POST['pagamento'];
    $telefone = $_POST['telefone'];
    $celular = $_POST['celular'];
    $jatemsite = $_POST['jatemsite'];
    $jatemlogo = $_POST['jatemlogo'];
    $jatemcartao = $_POST['jatemcartao'];
 	$mensagem = $_POST['mensagem'];
    $formadepagamento = $_POST['formadepagamento'];
    $qualosegmentodoseunegócio = $_POST['qualosegmentodoseunegócio'];


	//====================================================
 
	//Monta o Corpo da Mensagem
	//====================================================
$email_conteudo = "     nome $nome        \n"; 
$email_conteudo .= "    email $email       \n"; 
$email_conteudo .= "    cep $cep         \n"; 
$email_conteudo .= "    endereco $endereco    \n"; 
$email_conteudo .= "    numero $numero      \n"; 
$email_conteudo .= "    complemento $complemento \n"; 
$email_conteudo .= "    bairro $bairro      \n"; 
$email_conteudo .= "    site $site        \n"; 
$email_conteudo .= "    telefone $telefone    \n"; 
$email_conteudo .= "    celular $celular     \n"; 
$email_conteudo .= "    Quer um site $jatemsite   \n"; 
$email_conteudo .= "    quer uma logo $jatemlogo   \n"; 
$email_conteudo .= "    quer um cartão $jatemcartao \n"; 
$email_conteudo .= "    mensagem $mensagem    \n"; 
$email_conteudo .= "    formadepagamento $formadepagamento    \n"; 
$email_conteudo .= "    seguimento $qualosegmentodoseunegócio    \n"; 



 	//====================================================
 
	//Seta os Headers (Alerar somente caso necessario)
	//====================================================
	$email_headers = implode ( "\n",array ( "From: $email_remetente", "Reply-To: $email_reply", "Subject: $email_assunto","Return-Path:  $email_remetente","MIME-Version: 1.0","X-Priority: 3","Content-Type: text/html; charset=UTF-8" ) );
	//====================================================
 
 
	//Enviando o email
	//====================================================
	if (mail ($email_destinatario, $email_assunto, nl2br($email_conteudo), $email_headers)){
		echo "</p><center>Enviado!</center></p>"; 
	}
  	else{
		echo "</p><center>Falha!</center></p>";
	}
	//====================================================
}	
?>
 
 <div class="webe">
<form action="<? $PHP_SELF; ?>" method="POST"  name="meuform" method="POST" onsubmit="return aviso()">
    <p>
   
<input type="text" placeholder="Nome" required="2"  name="nome" maxLength="15">  
<input type="text" placeholder="E-mail" required="6" size="30" name="email" autocapitalize="off" autocorrect="off" spellcheck="false" name="email" maxLength="35" >  
<!--
<input type="text" placeholder="Segmento de negócio"  required="8" size="8" name="qualosegmentodoseunegócio" maxLength="200"> 
 
<input type="text" placeholder="CEP"  required="8" size="8" name="cep" maxLength="8" type="number"> 
<input type="text" placeholder="Endereço"  required="8" size="20" name="endereco"> 
<input type="text" placeholder="Numero"  required="8" size="20" name="numero" maxLength="4" type="number" > 
<input type="text" placeholder="Complemento"  required="8" size="20" name="complemento" maxLength="30"> 
<input type="text" placeholder="Bairro"  required="8" size="20" name="bairro" maxLength="15"> 
 
<input type="text" placeholder="Nome do seu Site"  required="8" size="20" name="site" maxLength="40"> 
<input type="text" placeholder="Quer uma LOGO"  required="8" size="20" name="jatemsite"> 
<input type="text" placeholder="Quer um SITE"  required="8" size="20" name="jatemlogo"> 
<input type="text" placeholder="Quer um CARTÃO"  required="8" size="20" name="jatemcartao">

-->
  <textarea name="mensagem" placeholder="Mensagem" required="10" id="mensagem" cols="35" rows="1"></textarea>


<input type="number" placeholder="Telefone"  required="8" size="20" name="telefone"> 
<input type="number" placeholder="Celular"  required="8" size="20" name="celular" > 
<center>
<!-- <p>Forma de pagamento
<select name="formadepagamento">

  <option value="1X">1X</option>
  <option value="2X">2X</option>
  <option value="3X">3X</option>

</select>
</p>

 -->

<!-- 
        <p>Forma de pagamento
      <input type="radio" id="1X" name="gender" value="1X">   <label for="1X">1X</label>    
      <input type="radio" id="2X" name="gender" value="2X"> <label for="2X">2X</label>    
      <input type="radio" id="3X" name="gender" value="3X">  <label for="3X">3X</label> 
      </p> 

     -->    
</center>
  
  
   
        <input type="submit" name="BTEnvia" value="Ok">


    </p>

</form>
</div>
</body>
</html>